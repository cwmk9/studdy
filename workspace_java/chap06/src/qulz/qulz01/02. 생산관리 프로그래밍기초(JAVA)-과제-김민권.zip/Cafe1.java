package qulz.qulz01;

public class Cafe1 {

	//커피, 스무디
	int coffee = 0;
	int smoothie = 0;
	int select = 0;
	int options = 0;
	int coffeeprice = 0;
	int smoothieprice = 0;
	
	Cafe1(int coffee, int smoothie){
		this.coffee=coffee;
		this.smoothie=smoothie;
	}	
	
	void menu() {
		System.out.println("=====================");
		System.out.println("메뉴를 선택해 주세요");
		System.out.println("1커피" + "2스무디");
		System.out.println("=====================");
		
	}
	
	void select(int select) {
		this.select=select;
		if(this.coffee == select) {
			System.out.println("커피");
			System.out.println("=====================");
			System.out.println("옵션을 선택해 주세요");
			System.out.println("1차갑게"+"2따뜻하게");
			System.out.println("=====================");
		}else if(this.smoothie == select) {
			System.out.println("스무디");
			System.out.println("=====================");
			System.out.println("옵션을 선택해 주세요");
			System.out.println("1블루베리"+"2스트로베리");
			System.out.println("=====================");
		}
	}
	
	void options(int options) {
		this.options=options;
		if(this.coffee == select) {
			this.coffeeprice = 3000;
			if(1==options) {
				System.out.println("아이스 아메리카노");
			}else if(2==(options)) {
				System.out.println("아메리카노");
			}
		}
		if(this.smoothie == select) {
			this.smoothieprice = 5000;
			if(1==options) {
				System.out.println("블루베리 스무디");
			}else if(2==options) {
				System.out.println("스트로베리 스무디");
			}
		}
	}
	
	void reset() {
		System.out.println("=====================");
		System.out.println("처음화면으로 돌아갑니다");
		System.out.println("=====================");
		int coffee = 0;
		int smoothie = 0;
		int select = 0;
		int options = 0;
		System.out.println("=====================");
		System.out.println("메뉴를 선택해 주세요");
		System.out.println("1커피" + "2스무디");
		System.out.println("=====================");
	}

	void basket () {
		
	}
}
