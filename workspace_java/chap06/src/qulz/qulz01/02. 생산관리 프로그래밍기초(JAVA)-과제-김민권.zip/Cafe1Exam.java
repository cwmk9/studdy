package qulz.qulz01;

public class Cafe1Exam {

	public static void main(String[] args) {
		
//		while(true) {
			Cafe1 cafe = new Cafe1(1,2);
			cafe.menu();
			cafe.select(2);
			cafe.options(1);
			cafe.reset();
//		}
		
	}

}
